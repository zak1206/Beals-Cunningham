<?php
include('updates/updatefiles/process.php');

echo 'WWENT';